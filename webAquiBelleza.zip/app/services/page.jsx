export default function ProfessionalMakeup() {
  return (
    <main className="pt-40 pb-20 text-center">
      <h1 className="font-title text-4xl uppercase tracking-widest">Sobre Nosotras</h1>
      <p className="mt-4 font-body text-gray-500">Próximamente...</p>
    </main>
  );
}