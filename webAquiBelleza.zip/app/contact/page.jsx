import Form from '@/components/Form'; 

export default function Contact() {
    return (
       <main className="flex-grow bg-gray-50/50 flex items-center justify-center pt-15 pb-32 max-md:pt-8 max-md:pb-15">

            <Form />

        </main>
      
    );
}